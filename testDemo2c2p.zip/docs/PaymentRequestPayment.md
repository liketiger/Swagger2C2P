# PaymentRequestPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | [**PaymentRequestPaymentCode**](PaymentRequestPaymentCode.md) |  |  [optional]
**data** | [**PaymentRequestPaymentData**](PaymentRequestPaymentData.md) |  |  [optional]
