# PaymentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paymentToken** | **String** |  | 
**clientID** | **String** |  | 
**locale** | **String** |  | 
**responseReturnUrl** | **String** |  | 
**payment** | [**PaymentRequestPayment**](PaymentRequestPayment.md) |  | 
