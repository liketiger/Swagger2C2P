# PaymentTokenResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | **String** |  |  [optional]
**respCode** | **String** |  |  [optional]
**respDesc** | **String** |  |  [optional]
