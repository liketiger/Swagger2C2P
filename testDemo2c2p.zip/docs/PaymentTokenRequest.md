# PaymentTokenRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantID** | **String** |  | 
**invoiceNo** | **String** |  | 
**description** | **String** |  | 
**amount** | **String** |  | 
**currencyCode** | **String** |  |  [optional]
**payload** | **String** |  |  [optional]
