# PaymentAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paymentRequest** | **String** |  | 
