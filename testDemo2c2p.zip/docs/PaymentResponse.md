# PaymentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channelCode** | **String** |  |  [optional]
**data** | **String** |  |  [optional]
**respCode** | **String** |  |  [optional]
**respDesc** | **String** |  |  [optional]
