# PaymentRequestPaymentCode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channelCode** | **String** |  |  [optional]
